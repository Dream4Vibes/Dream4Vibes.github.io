using System;
using System.Xml.Serialization;

namespace LogistPro.Models
{
    [XmlRoot("Movement")]
    public class Movement
    {
        [XmlElement]
        public int Id { get; set; }

        [XmlElement]
        public int StoreId { get; set; }

        [XmlElement]
        public int ProductId { get; set; }

        [XmlElement]
        public string Type { get; set; } // "In" (приход) или "Out" (расход)

        [XmlElement]
        public int Amount { get; set; }

        [XmlElement]
        public DateTime Date { get; set; }
    }
}
