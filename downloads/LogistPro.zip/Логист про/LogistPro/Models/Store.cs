using System.Xml.Serialization;

namespace LogistPro.Models
{
    [XmlRoot("Store")]
    public class Store
    {
        [XmlElement]
        public int Id { get; set; }

        [XmlElement]
        public string Name { get; set; }
    }
}
