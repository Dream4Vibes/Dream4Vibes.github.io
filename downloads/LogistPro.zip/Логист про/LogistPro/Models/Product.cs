using System.Xml.Serialization;

namespace LogistPro.Models
{
    [XmlRoot("Product")]
    public class Product
    {
        [XmlElement]
        public int Id { get; set; }

        [XmlElement]
        public string Name { get; set; }

        [XmlElement]
        public string Article { get; set; }      // Артикул

        [XmlElement]
        public string Unit { get; set; }          // Единица измерения

        [XmlElement]
        public decimal Price { get; set; }        // Цена за единицу

        [XmlElement]
        public int MinStock { get; set; }         // Минимальный порог
    }
}
