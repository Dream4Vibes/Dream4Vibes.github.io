using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using LogistPro.Models;
using LogistPro.Services;

namespace LogistPro.UI
{
    public class HistoryRow
    {
        public string DateStr { get; set; }
        public string TypeStr { get; set; }
        public int Amount { get; set; }
    }

    public partial class MovementHistoryDialog : Window
    {
        public MovementHistoryDialog(WarehouseManager manager, int storeId, int productId)
        {
            InitializeComponent();

            var store = manager.GetStores().FirstOrDefault(s => s.Id == storeId);
            var product = manager.GetProducts().FirstOrDefault(p => p.Id == productId);

            TitleText.Text = $"История движений: {product?.Name ?? "Товар"} на {store?.Name ?? "Склад"}";

            var movements = manager.GetMovements()
                .Where(m => m.StoreId == storeId && m.ProductId == productId)
                .OrderByDescending(m => m.Date)
                .Select(m => new HistoryRow
                {
                    DateStr = m.Date.ToString("dd.MM.yyyy HH:mm"),
                    TypeStr = m.Type == "In" ? "Приход" : "Расход",
                    Amount = m.Amount
                })
                .ToList();

            HistoryGrid.ItemsSource = movements;
        }

        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
