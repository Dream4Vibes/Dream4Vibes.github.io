using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using LogistPro.Models;
using LogistPro.Services;

namespace LogistPro.UI
{
    public partial class MovementDialog : Window
    {
        private readonly WarehouseManager _manager;

        public MovementDialog(WarehouseManager manager)
        {
            InitializeComponent();
            _manager = manager;
            LoadData();
        }

        private void LoadData()
        {
            CmbStore.ItemsSource = _manager.GetStores();
            CmbProduct.ItemsSource = _manager.GetProducts();
            CmbType.Items.Add("Приход");
            CmbType.Items.Add("Расход");
            CmbType.SelectedIndex = 0;

            if (CmbStore.Items.Count > 0) CmbStore.SelectedIndex = 0;
            if (CmbProduct.Items.Count > 0) CmbProduct.SelectedIndex = 0;
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            if (CmbStore.SelectedItem == null)
            {
                MessageBox.Show("Пожалуйста, выберите склад.", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (CmbProduct.SelectedItem == null)
            {
                MessageBox.Show("Пожалуйста, выберите товар.", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (CmbType.SelectedItem == null)
            {
                MessageBox.Show("Пожалуйста, выберите тип операции.", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (!int.TryParse(TxtAmount.Text, out int amount) || amount <= 0)
            {
                MessageBox.Show("Пожалуйста, введите корректное количество (целое положительное число).",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var store = (Store)CmbStore.SelectedItem;
            var product = (Product)CmbProduct.SelectedItem;
            string type = CmbType.SelectedItem.ToString() == "Приход" ? "In" : "Out";

            bool success = _manager.TryProcessMovement(store.Id, product.Id, amount, type);
            if (success)
            {
                DialogResult = true;
                Close();
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        private void TxtAmount_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            // Разрешаем только цифры
            foreach (char c in e.Text)
            {
                if (!char.IsDigit(c))
                {
                    e.Handled = true;
                    return;
                }
            }
        }
    }
}
