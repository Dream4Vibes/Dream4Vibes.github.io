using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using LogistPro.Services;

namespace LogistPro.UI
{
    public partial class StockContent : UserControl
    {
        private readonly WarehouseManager _manager;
        private readonly MainWindow _mainWindow;
        private List<StockItem> _allStockItems;

        public StockContent(WarehouseManager manager, MainWindow mainWindow)
        {
            InitializeComponent();
            _manager = manager;
            _mainWindow = mainWindow;
            LoadData();
        }

        private void LoadData()
        {
            _allStockItems = _manager.GetStockItems();
            StockGrid.ItemsSource = _allStockItems;
        }

        private void SearchBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            string query = SearchBox.Text.Trim().ToLower();
            if (string.IsNullOrEmpty(query))
            {
                StockGrid.ItemsSource = _allStockItems;
            }
            else
            {
                var filtered = _allStockItems.Where(s =>
                    s.ProductName.ToLower().Contains(query) ||
                    s.Article.ToLower().Contains(query)).ToList();
                StockGrid.ItemsSource = filtered;
            }
        }

        private void StockGrid_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (StockGrid.SelectedItem is StockItem item)
            {
                var dialog = new MovementHistoryDialog(_manager, item.StoreId, item.ProductId);
                dialog.Owner = _mainWindow;
                dialog.ShowDialog();
            }
        }
    }
}
