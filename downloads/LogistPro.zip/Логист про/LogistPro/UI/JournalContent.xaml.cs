using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media; // <--- ДОБАВЛЕНО ЭТО ПРОСТРАНСТВО ИМЕН
using LogistPro.Models;
using LogistPro.Services;

namespace LogistPro.UI
{
    public class JournalRow
    {
        public string DateStr { get; set; }
        public string StoreName { get; set; }
        public string ProductName { get; set; }
        public string TypeStr { get; set; }
        public int Amount { get; set; }
        public decimal Sum { get; set; }
    }

    public partial class JournalContent : UserControl
    {
        private readonly WarehouseManager _manager;
        private readonly MainWindow _mainWindow;
        private List<JournalRow> _allRows;

        public JournalContent(WarehouseManager manager, MainWindow mainWindow)
        {
            InitializeComponent();
            _manager = manager;
            _mainWindow = mainWindow;
            LoadData();
            ShowAll();
        }

        private void LoadData()
        {
            var movements = _manager.GetMovements();
            var stores = _manager.GetStores();
            var products = _manager.GetProducts();

            _allRows = new List<JournalRow>();

            foreach (var m in movements)
            {
                var store = stores.FirstOrDefault(s => s.Id == m.StoreId);
                var product = products.FirstOrDefault(p => p.Id == m.ProductId);

                _allRows.Add(new JournalRow
                {
                    DateStr = m.Date.ToString("dd.MM.yyyy HH:mm"),
                    StoreName = store?.Name ?? "Неизвестно",
                    ProductName = product?.Name ?? "Неизвестно",
                    TypeStr = m.Type == "In" ? "Приход" : "Расход",
                    Amount = m.Amount,
                    Sum = m.Amount * (product?.Price ?? 0)
                });
            }

            _allRows = _allRows.OrderByDescending(r => r.DateStr).ToList();
        }

        private void ShowAll()
        {
            JournalGrid.ItemsSource = _allRows;
            UpdateFilterButtons(BtnAll);
        }

        private void ShowToday()
        {
            var today = DateTime.Now.ToString("dd.MM.yyyy");
            JournalGrid.ItemsSource = _allRows.Where(r => r.DateStr.StartsWith(today)).ToList();
            UpdateFilterButtons(BtnToday);
        }

        private void ShowWeek()
        {
            var weekAgo = DateTime.Now.AddDays(-7);
            var filtered = _allRows.Where(r =>
            {
                if (DateTime.TryParseExact(r.DateStr.Substring(0, 10), "dd.MM.yyyy",
                    System.Globalization.CultureInfo.InvariantCulture,
                    System.Globalization.DateTimeStyles.None, out DateTime date))
                {
                    return date >= weekAgo;
                }
                return false;
            }).ToList();
            JournalGrid.ItemsSource = filtered;
            UpdateFilterButtons(BtnWeek);
        }

        // Указываем полный путь к Button, чтобы избежать конфликта с вашим пользовательским классом
        private void UpdateFilterButtons(System.Windows.Controls.Button active)
        {
            // Теперь код стал намного чище благодаря using System.Windows.Media
            Color defaultBg = (Color)ColorConverter.ConvertFromString("#E8F0FE");
            Color defaultFg = (Color)ColorConverter.ConvertFromString("#1A73E8");
            Color activeBg = (Color)ColorConverter.ConvertFromString("#1A73E8");

            BtnToday.Background = BtnWeek.Background = BtnAll.Background = new SolidColorBrush(defaultBg);
            BtnToday.Foreground = BtnWeek.Foreground = BtnAll.Foreground = new SolidColorBrush(defaultFg);

            active.Background = new SolidColorBrush(activeBg);
            active.Foreground = new SolidColorBrush(Colors.White); // <--- ОШИБКА ИСПРАВЛЕНА
        }

        private void BtnToday_Click(object sender, RoutedEventArgs e) => ShowToday();
        private void BtnWeek_Click(object sender, RoutedEventArgs e) => ShowWeek();
        private void BtnAll_Click(object sender, RoutedEventArgs e) => ShowAll();

        private void BtnNewMovement_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new MovementDialog(_manager);
            dialog.Owner = _mainWindow;
            if (dialog.ShowDialog() == true)
            {
                LoadData();
                JournalGrid.ItemsSource = _allRows;
            }
        }

        private void BtnExportXml_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string fileName = $"Journal_{DateTime.Now:yyyyMMdd_HHmmss}.xml";
                _manager.ExportMovementsToXml(fileName);
                MessageBox.Show($"Журнал движений успешно экспортирован в файл:\n{fileName}",
                    "Экспорт завершён", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при экспорте: {ex.Message}",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}