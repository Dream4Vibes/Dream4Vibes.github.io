using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using LogistPro.Services;

namespace LogistPro.UI
{
    public class AnalyticsRow
    {
        public string StoreName { get; set; }
        public string ProductName { get; set; }
        public string Article { get; set; }
        public int CurrentStock { get; set; }
        public int MinStock { get; set; }
        public int Recommended { get; set; }
        public string Status { get; set; }
    }

    public partial class AnalyticsContent : UserControl
    {
        private readonly WarehouseManager _manager;
        private readonly MainWindow _mainWindow;

        public AnalyticsContent(WarehouseManager manager, MainWindow mainWindow)
        {
            InitializeComponent();
            _manager = manager;
            _mainWindow = mainWindow;
            LoadData();
        }

        private void LoadData()
        {
            var lowStockItems = _manager.GetLowStockItems();
            var rows = lowStockItems.Select(item => new AnalyticsRow
            {
                StoreName = item.StoreName,
                ProductName = item.ProductName,
                Article = item.Article,
                CurrentStock = item.CurrentStock,
                MinStock = item.MinStock,
                Recommended = _manager.CalculateRecommendedAmount(item),
                Status = item.Status
            }).ToList();

            AnalyticsGrid.ItemsSource = rows;
            LowStockInfo.Text = $"Товары с низким остатком: {lowStockItems.Count}";
        }

        private void BtnGenerateOrder_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string filePath = _manager.GenerateOrderFile();
                if (filePath != null)
                {
                    MessageBox.Show(
                        $"Заявка на пополнение успешно сформирована!\nФайл: {filePath}",
                        "Заявка сформирована",
                        MessageBoxButton.OK,
                        MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при формировании заявки: {ex.Message}",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnExportStockXml_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string fileName = $"Stock_{DateTime.Now:yyyyMMdd_HHmmss}.xml";
                _manager.ExportStockToXml(fileName);
                MessageBox.Show($"Остатки успешно экспортированы в файл:\n{fileName}",
                    "Экспорт завершён", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при экспорте: {ex.Message}",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
