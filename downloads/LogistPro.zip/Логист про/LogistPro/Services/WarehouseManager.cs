using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Serialization;
using LogistPro.Models;

namespace LogistPro.Services
{
    [XmlRoot("StockItem")]
    public class StockItem
    {
        [XmlElement]
        public int StoreId { get; set; }

        [XmlElement]
        public string StoreName { get; set; }

        [XmlElement]
        public int ProductId { get; set; }

        [XmlElement]
        public string ProductName { get; set; }

        [XmlElement]
        public string Article { get; set; }

        [XmlElement]
        public string Unit { get; set; }

        [XmlElement]
        public int CurrentStock { get; set; }

        [XmlElement]
        public int MinStock { get; set; }

        [XmlIgnore]
        public string Status
        {
            get
            {
                if (CurrentStock == 0) return "Нет в наличии";
                if (CurrentStock <= MinStock) return "Низкий остаток";
                return "В норме";
            }
        }

        [XmlIgnore]
        public string StatusColor
        {
            get
            {
                if (CurrentStock == 0) return "Gray";
                if (CurrentStock <= MinStock) return "Red";
                return "Green";
            }
        }
    }

    public class WarehouseManager
    {
        private List<Store> _stores;
        private List<Product> _products;
        private List<Movement> _movements;
        private List<StockItem> _stockItems;

        private readonly CsvParser _csvParser;
        private readonly XmlParser _xmlParser;

        public WarehouseManager()
        {
            _csvParser = new CsvParser();
            _xmlParser = new XmlParser();
            _stores = new List<Store>();
            _products = new List<Product>();
            _movements = new List<Movement>();
            _stockItems = new List<StockItem>();
        }

        public void LoadData()
        {
            string dataPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Data");
            _stores = _csvParser.ParseStores(Path.Combine(dataPath, "stores.csv"));
            _products = _csvParser.ParseProducts(Path.Combine(dataPath, "products.csv"));
            _movements = _csvParser.ParseMovements(Path.Combine(dataPath, "movements.csv"));
            RecalculateStocks();
        }

        // Алгоритм 1: Расчёт остатков
        public void RecalculateStocks()
        {
            var stockDict = new Dictionary<string, int>();

            foreach (var m in _movements)
            {
                string key = $"{m.StoreId}_{m.ProductId}";
                if (!stockDict.ContainsKey(key))
                    stockDict[key] = 0;

                if (m.Type == "In") stockDict[key] += m.Amount;
                else if (m.Type == "Out") stockDict[key] -= m.Amount;
            }

            _stockItems = new List<StockItem>();
            foreach (var store in _stores)
            {
                foreach (var product in _products)
                {
                    string key = $"{store.Id}_{product.Id}";
                    int current = stockDict.ContainsKey(key) ? stockDict[key] : 0;

                    _stockItems.Add(new StockItem
                    {
                        StoreId = store.Id,
                        StoreName = store.Name,
                        ProductId = product.Id,
                        ProductName = product.Name,
                        Article = product.Article,
                        Unit = product.Unit,
                        CurrentStock = current,
                        MinStock = product.MinStock
                    });
                }
            }
        }

        public List<Store> GetStores() => _stores;
        public List<Product> GetProducts() => _products;
        public List<Movement> GetMovements() => _movements;
        public List<StockItem> GetStockItems() => _stockItems;

        // Алгоритм 2: Проверка на отрицательный остаток
        public bool TryProcessMovement(int storeId, int productId, int amount, string type)
        {
            if (type == "Out")
            {
                var stock = _stockItems.FirstOrDefault(s => s.StoreId == storeId && s.ProductId == productId);
                if (stock == null || stock.CurrentStock < amount)
                {
                    System.Windows.MessageBox.Show(
                        "Недостаточно товара на складе! Операция не может быть выполнена.",
                        "Ошибка",
                        System.Windows.MessageBoxButton.OK,
                        System.Windows.MessageBoxImage.Error);
                    return false;
                }
            }

            var newMovement = new Movement
            {
                Id = _movements.Count + 1,
                StoreId = storeId,
                ProductId = productId,
                Amount = amount,
                Type = type,
                Date = DateTime.Now
            };

            _movements.Add(newMovement);
            RecalculateStocks();
            return true;
        }

        // Алгоритм 3: Поиск красных позиций
        public List<StockItem> GetLowStockItems()
        {
            return _stockItems.Where(s => s.CurrentStock <= s.MinStock).ToList();
        }

        // Расчёт рекомендуемого количества для заказа
        public int CalculateRecommendedAmount(StockItem item)
        {
            int recommended = (item.MinStock * 2) - item.CurrentStock;
            return recommended > 0 ? recommended : item.MinStock;
        }

        // Формирование заявки на пополнение
        public string GenerateOrderFile()
        {
            var lowStockItems = GetLowStockItems();
            if (lowStockItems.Count == 0)
            {
                System.Windows.MessageBox.Show(
                    "Нет позиций с низким остатком для формирования заявки.",
                    "Информация",
                    System.Windows.MessageBoxButton.OK,
                    System.Windows.MessageBoxImage.Information);
                return null;
            }

            if (!Directory.Exists("Orders"))
                Directory.CreateDirectory("Orders");

            string fileName = $"Order_{DateTime.Now:yyyyMMdd}.txt";
            string filePath = Path.Combine("Orders", fileName);

            using (var writer = new StreamWriter(filePath, false, System.Text.Encoding.UTF8))
            {
                writer.WriteLine($"Заявка на пополнение запасов");
                writer.WriteLine($"Дата формирования: {DateTime.Now:dd.MM.yyyy HH:mm:ss}");
                writer.WriteLine(new string('=', 60));

                var groupedByStore = lowStockItems.GroupBy(s => s.StoreName);
                foreach (var storeGroup in groupedByStore)
                {
                    writer.WriteLine();
                    writer.WriteLine($"Склад: {storeGroup.Key}");
                    writer.WriteLine(new string('-', 40));
                    writer.WriteLine($"{"Товар",-30} {"Артикул",-12} {"Остаток",-10} {"Мин.",-8} {"Заказ",-8}");
                    writer.WriteLine(new string('-', 40));

                    foreach (var item in storeGroup)
                    {
                        int recommended = CalculateRecommendedAmount(item);
                        writer.WriteLine($"{item.ProductName,-30} {item.Article,-12} {item.CurrentStock,-10} {item.MinStock,-8} {recommended,-8}");
                    }
                }

                writer.WriteLine();
                writer.WriteLine(new string('=', 60));
                writer.WriteLine($"Всего позиций к заказу: {lowStockItems.Count}");
            }

            return filePath;
        }

        // Экспорт журнала движений в XML
        public void ExportMovementsToXml(string filePath)
        {
            _xmlParser.ExportMovementsToXml(_movements, filePath);
        }

        // Экспорт остатков в XML
        public void ExportStockToXml(string filePath)
        {
            _xmlParser.ExportStockToXml(_stockItems, filePath);
        }
    }
}
