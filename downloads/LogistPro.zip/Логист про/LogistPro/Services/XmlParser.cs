using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;
using LogistPro.Models;

namespace LogistPro.Services
{
    public class XmlParser
    {
        public void ExportMovementsToXml(List<Movement> movements, string filePath)
        {
            var serializer = new XmlSerializer(typeof(List<Movement>));
            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                serializer.Serialize(stream, movements);
            }
        }

        public void ExportStockToXml(List<StockItem> stockItems, string filePath)
        {
            var serializer = new XmlSerializer(typeof(List<StockItem>));
            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                serializer.Serialize(stream, stockItems);
            }
        }
    }
}
