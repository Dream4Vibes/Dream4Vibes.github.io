using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using LogistPro.Models;

namespace LogistPro.Services
{
    public class CsvParser
    {
        private readonly string _errorLogPath = "errors.log";

        public List<Store> ParseStores(string filePath)
        {
            var result = new List<Store>();
            if (!File.Exists(filePath))
            {
                ShowFileMissingMessage(filePath);
                return result;
            }

            var lines = File.ReadAllLines(filePath);
            for (int i = 1; i < lines.Length; i++) // skip header
            {
                try
                {
                    var parts = lines[i].Split(';');
                    if (parts.Length < 2) throw new FormatException("Недостаточно колонок");
                    result.Add(new Store
                    {
                        Id = int.Parse(parts[0].Trim()),
                        Name = parts[1].Trim()
                    });
                }
                catch (Exception ex)
                {
                    LogError($"Строка {i + 1} файла {filePath}: {ex.Message}");
                }
            }
            return result;
        }

        public List<Product> ParseProducts(string filePath)
        {
            var result = new List<Product>();
            if (!File.Exists(filePath))
            {
                ShowFileMissingMessage(filePath);
                return result;
            }

            var lines = File.ReadAllLines(filePath);
            for (int i = 1; i < lines.Length; i++)
            {
                try
                {
                    var parts = lines[i].Split(';');
                    if (parts.Length < 5) throw new FormatException("Недостаточно колонок");
                    result.Add(new Product
                    {
                        Id = int.Parse(parts[0].Trim()),
                        Name = parts[1].Trim(),
                        Article = parts[2].Trim(),
                        Unit = parts[3].Trim(),
                        // ИСПРАВЛЕНО ЗДЕСЬ: Добавлено CultureInfo.InvariantCulture
                        Price = decimal.Parse(parts[4].Trim(), System.Globalization.CultureInfo.InvariantCulture),
                        MinStock = parts.Length > 5 ? int.Parse(parts[5].Trim()) : 0
                    });
                }
                catch (Exception ex)
                {
                    LogError($"Строка {i + 1} файла {filePath}: {ex.Message}");
                }
            }
            return result;
        }

        public List<Movement> ParseMovements(string filePath)
        {
            var result = new List<Movement>();
            if (!File.Exists(filePath))
            {
                ShowFileMissingMessage(filePath);
                return result;
            }

            var lines = File.ReadAllLines(filePath);
            for (int i = 1; i < lines.Length; i++)
            {
                try
                {
                    var parts = lines[i].Split(';');
                    if (parts.Length < 6) throw new FormatException("Недостаточно колонок");
                    result.Add(new Movement
                    {
                        Id = int.Parse(parts[0].Trim()),
                        StoreId = int.Parse(parts[1].Trim()),
                        ProductId = int.Parse(parts[2].Trim()),
                        Type = parts[3].Trim(),
                        Amount = int.Parse(parts[4].Trim()),
                        Date = DateTime.Parse(parts[5].Trim())
                    });
                }
                catch (Exception ex)
                {
                    LogError($"Строка {i + 1} файла {filePath}: {ex.Message}");
                }
            }
            return result;
        }

        private void LogError(string message)
        {
            File.AppendAllText(_errorLogPath,
                $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {message}{Environment.NewLine}");
        }

        private void ShowFileMissingMessage(string filePath)
        {
            System.Windows.MessageBox.Show(
                $"Файл данных не найден: {filePath}\nПожалуйста, убедитесь, что файл существует и повторите попытку.",
                "Файл не найден",
                System.Windows.MessageBoxButton.OK,
                System.Windows.MessageBoxImage.Warning);
        }
    }
}
