using System;
using System.Windows;
using System.Windows.Controls;
using LogistPro.Services;
using LogistPro.UI;

namespace LogistPro
{
    public partial class MainWindow : Window
    {
        private readonly WarehouseManager _manager;

        public MainWindow()
        {
            InitializeComponent();
            _manager = new WarehouseManager();
            _manager.LoadData();
            NavigateToStock();
        }

        public WarehouseManager Manager => _manager;

        private void NavigateToStock()
        {
            PageTitle.Text = "Остатки на складах";
            PageSubtitle.Text = "Просмотр текущих остатков товаров по складам";
            ContentArea.Content = new StockContent(_manager, this);
            UpdateNavButtons(BtnStock);
        }

        private void NavigateToJournal()
        {
            PageTitle.Text = "Журнал движений";
            PageSubtitle.Text = "Просмотр истории приходных и расходных операций";
            ContentArea.Content = new JournalContent(_manager, this);
            UpdateNavButtons(BtnJournal);
        }

        private void NavigateToAnalytics()
        {
            PageTitle.Text = "Аналитика и заказы";
            PageSubtitle.Text = "Товары с низким остатком и формирование заявок на пополнение";
            ContentArea.Content = new AnalyticsContent(_manager, this);
            UpdateNavButtons(BtnAnalytics);
        }

        // Используем полное имя типа System.Windows.Controls.Button
        private void UpdateNavButtons(System.Windows.Controls.Button activeButton)
        {
            BtnStock.Style = (Style)FindResource("NavButtonStyle");
            BtnJournal.Style = (Style)FindResource("NavButtonStyle");
            BtnAnalytics.Style = (Style)FindResource("NavButtonStyle");
            activeButton.Style = (Style)FindResource("NavButtonActiveStyle");
        }

        private void BtnStock_Click(object sender, RoutedEventArgs e)
        {
            NavigateToStock();
        }

        private void BtnJournal_Click(object sender, RoutedEventArgs e)
        {
            NavigateToJournal();
        }

        private void BtnAnalytics_Click(object sender, RoutedEventArgs e)
        {
            NavigateToAnalytics();
        }

        private void BtnNewMovement_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new MovementDialog(_manager);
            dialog.Owner = this;
            if (dialog.ShowDialog() == true)
            {
                _manager.RecalculateStocks();
                RefreshCurrentContent();
            }
        }

        private void BtnExportXml_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string fileName = $"Journal_{DateTime.Now:yyyyMMdd_HHmmss}.xml";
                _manager.ExportMovementsToXml(fileName);
                MessageBox.Show($"Журнал движений успешно экспортирован в файл:\n{fileName}",
                    "Экспорт завершён", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при экспорте: {ex.Message}",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        public void RefreshCurrentContent()
        {
            if (ContentArea.Content is StockContent)
                NavigateToStock();
            else if (ContentArea.Content is JournalContent)
                NavigateToJournal();
            else if (ContentArea.Content is AnalyticsContent)
                NavigateToAnalytics();
        }
    }
}