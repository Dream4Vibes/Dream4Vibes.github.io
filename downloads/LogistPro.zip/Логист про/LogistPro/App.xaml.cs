using System.Windows;

namespace LogistPro
{
    public partial class App : Application
    {
    }
}
