﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using LogistPro.Services;

namespace LogistPro.Windows
{
    public partial class MainWindow : Window
    {
        public static WarehouseService Warehouse { get; private set; }

        public MainWindow()
        {
            InitializeComponent();
            Loaded += MainWindow_Loaded;
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            // Инициализация сервисов
            var fileService = new FileService();
            Warehouse = new WarehouseService(fileService);


            // Показать главную страницу по умолчанию
            ShowDashboard();

           
        }

        private void SetPageTitle(string title) => TxtPageTitle.Text = title;

        private void ShowDashboard()
        {
            SetPageTitle("Панель управления");
            MainContent.Content = CreateDashboardContent();
        }

        private void BtnHome_Click(object sender, RoutedEventArgs e) => ShowDashboard();
        private void BtnStock_Click(object sender, RoutedEventArgs e)
        {
            SetPageTitle("Остатки на складах");
            var content = new StockContent();
            MainContent.Content = content;
            // Авто-обновление при открытии
            content.ForceRefresh();
        }

        private void BtnJournal_Click(object sender, RoutedEventArgs e)
        {
            SetPageTitle("Журнал операций");
            var content = new JournalContent();
            MainContent.Content = content;
            // Авто-обновление при открытии
            content.ForceRefresh();
        }

        private void BtnAnalytics_Click(object sender, RoutedEventArgs e)
        {
            SetPageTitle("Аналитика и заказы");
            var content = new AnalyticsContent();
            MainContent.Content = content;
            // Авто-обновление при открытии
            content.ForceRefresh();
        }
        private void BtnExit_Click(object sender, RoutedEventArgs e) => Close();

        // Простая дашборд-панель
        private Grid CreateDashboardContent()
        {
            var grid = new Grid();
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

            // Приветствие
            var welcome = new TextBlock
            {
                Text = "Добро пожаловать в Логист-Про",
                FontSize = 20,
                FontWeight = FontWeights.Medium,
                Margin = new Thickness(0, 0, 0, 24)
            };
            Grid.SetRow(welcome, 0);
            grid.Children.Add(welcome);

            // Карточки статистики
            var statsPanel = new WrapPanel { Orientation = Orientation.Horizontal };

            var products = Warehouse?.GetProducts()?.Count ?? 0;
            var ops = Warehouse?.GetOperations()?.Count ?? 0;
            var lowStock = Warehouse?.GetLowStockProducts()?.Count ?? 0;

            statsPanel.Children.Add(CreateStatCard("📦 Товаров", products.ToString(), "#0D47A1"));
            statsPanel.Children.Add(CreateStatCard("📋 Операций", ops.ToString(), "#1565C0"));
            statsPanel.Children.Add(CreateStatCard("⚠️ Низкий остаток", lowStock.ToString(), "#F57C00"));

            Grid.SetRow(statsPanel, 1);
            grid.Children.Add(statsPanel);

            return grid;
        }

        private Border CreateStatCard(string label, string value, string color)
        {
            var border = new Border
            {
                Style = Application.Current.FindResource("Card.Standard") as Style,
                Width = 200,
                Margin = new Thickness(0, 0, 16, 0)
            };

            var stack = new StackPanel();
            stack.Children.Add(new TextBlock { Text = label, FontSize = 13, Foreground = (Brush)Application.Current.FindResource("Brush.Text.Light") });
            stack.Children.Add(new TextBlock { Text = value, FontSize = 28, FontWeight = FontWeights.Bold, Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString(color)), Margin = new Thickness(0, 8, 0, 0) });

            border.Child = stack;
            return border;
        }

       
    }
}