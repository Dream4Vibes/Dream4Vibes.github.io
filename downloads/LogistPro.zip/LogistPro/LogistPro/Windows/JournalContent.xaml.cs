﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using LogistPro.Models;

namespace LogistPro.Windows
{
    public partial class JournalContent : UserControl
    {
        public JournalContent()
        {
            InitializeComponent();
            Loaded += JournalContent_Loaded;
        }

        public void ForceRefresh()
        {
            LoadData();
        }

        private void JournalContent_Loaded(object sender, RoutedEventArgs e) => LoadData();

        private void LoadData()
        {
            try
            {
                if (MainWindow.Warehouse == null) return;

                DgJournal.ItemsSource = MainWindow.Warehouse.GetOperations()
                    .OrderByDescending(o => o.Date)
                    .ToList();
                TxtInfo.Text = $"Всего операций: {DgJournal.Items.Count}";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnProcess_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (!int.TryParse(TxtProductId.Text, out int productId))
                    throw new FormatException("Неверный ID товара");
                if (!int.TryParse(TxtAmount.Text, out int amount) || amount <= 0)
                    throw new FormatException("Неверное количество");

                var type = ((ComboBoxItem)CbType.SelectedItem)?.Tag?.ToString();
                if (string.IsNullOrEmpty(type))
                    throw new Exception("Выберите тип операции");

                MainWindow.Warehouse.TryProcessOperation(productId, amount, type);
                LoadData();

                TxtProductId.Clear();
                TxtAmount.Clear();
                MessageBox.Show("Операция выполнена успешно", "Успех",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (FormatException ex)
            {
                MessageBox.Show($"Проверьте ввод: {ex.Message}", "Ошибка ввода",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка операции",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}