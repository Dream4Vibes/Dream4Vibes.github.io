﻿using System.Linq;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Input;
using LogistPro.Models;

namespace LogistPro.Windows
{
    public partial class OperationDialog : Window
    {
        public int Amount { get; private set; }
        private readonly Product _product;
        private readonly string _operationType;

        public OperationDialog(int productId, string type)
        {
            InitializeComponent();
            _product = MainWindow.Warehouse.GetProducts().FirstOrDefault(p => p.Id == productId);
            _operationType = type;

            TxtTitle.Text = $"{(type == "In" ? "➕ Приход" : "➖ Расход")}: {_product?.Name}";
            TxtCurrentStock.Text = $"Текущий остаток: {_product?.CurrentStock} ед.";

            if (type == "Out")
                TxtAmount.ToolTip = $"Максимум: {_product?.CurrentStock}";
        }

        private void TxtAmount_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !Regex.IsMatch(e.Text, @"^\d+$");
        }

        private void BtnConfirm_Click(object sender, RoutedEventArgs e)
        {
            if (int.TryParse(TxtAmount.Text, out int amount) && amount > 0)
            {
                if (_operationType == "Out" && amount > _product.CurrentStock)
                {
                    MessageBox.Show("Недостаточно товара на складе!", "Ошибка",
                        MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }
                Amount = amount;
                DialogResult = true;
                Close();
            }
            else
            {
                MessageBox.Show("Введите корректное количество", "Ошибка ввода",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
    }
}