﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using LogistPro.Models;

namespace LogistPro.Windows
{
    public class AnalyticsItem
    {
        public Product Source { get; set; }
        public string Name => Source?.Name ?? "Неизвестно";
        public int CurrentStock => Source?.CurrentStock ?? 0;
        public int MinStock => Source?.MinStock ?? 0;
        public int RecommendedOrder { get; set; }
        public bool IsSelected { get; set; }
    }

    public partial class AnalyticsContent : UserControl
    {
        private List<AnalyticsItem> _items;

        public AnalyticsContent()
        {
            InitializeComponent();
            Loaded += AnalyticsContent_Loaded;
        }

        // ✅ ПУБЛИЧНЫЙ МЕТОД ДЛЯ АВТООБНОВЛЕНИЯ
        public void ForceRefresh()
        {
            LoadData();
        }

        private void AnalyticsContent_Loaded(object sender, RoutedEventArgs e) => LoadData();

        private void LoadData()
        {
            try
            {
                if (MainWindow.Warehouse == null)
                {
                    MessageBox.Show("Сервис Warehouse не инициализирован", "Ошибка",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                var products = MainWindow.Warehouse.GetProducts();
                if (products == null) products = new List<Product>();

                var lowStock = MainWindow.Warehouse.GetLowStockProducts();
                if (lowStock == null) lowStock = new List<Product>();

                _items = new List<AnalyticsItem>();

                var filterLow = CbFilter?.SelectedIndex == 1;
                var sourceList = filterLow ? lowStock : products;

                foreach (var p in sourceList)
                {
                    if (p == null) continue;

                    int recommended = MainWindow.Warehouse.CalculateRecommendedAmount(p);

                    _items.Add(new AnalyticsItem
                    {
                        Source = p,
                        RecommendedOrder = recommended,
                        IsSelected = lowStock.Contains(p)
                    });
                }

                if (DgAnalytics != null)
                {
                    DgAnalytics.ItemsSource = _items;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки аналитики:\n{ex.Message}",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CbFilter_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (MainWindow.Warehouse != null)
                LoadData();
        }

        private void BtnRefresh_Click(object sender, RoutedEventArgs e) => LoadData();

        private void BtnExportOrder_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (MainWindow.Warehouse == null)
                {
                    MessageBox.Show("Warehouse не инициализирован", "Ошибка",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                if (_items == null || !_items.Any())
                {
                    MessageBox.Show("Нет данных для экспорта", "Внимание",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }

                var selected = _items.Where(i => i.IsSelected).Select(i => i.Source).ToList();
                if (!selected.Any())
                {
                    MessageBox.Show("Выберите товары для заказа", "Внимание",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }

                var path = $"Order_{DateTime.Now:yyyyMMdd_HHmm}.xml";
                MainWindow.Warehouse.ExportOrdersToXml(selected, path);
                MessageBox.Show($"✅ Заявка сформирована:\n{path}", "Успех",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка экспорта",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}