﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using LogistPro.Models;

namespace LogistPro.Windows
{
    // ✅ Класс для отображения в таблице с готовым статусом
    public class StockItem
    {
        public Product Source { get; set; }
        public int Id => Source.Id;
        public string Name => Source.Name;
        public int CurrentStock => Source.CurrentStock;
        public int MinStock => Source.MinStock;

        // Готовый текст статуса
        public string StatusText
        {
            get
            {
                if (CurrentStock == 0) return "Нет в наличии";
                if (CurrentStock <= MinStock) return "Низкий остаток";
                return "В норме";
            }
        }

        // Готовый цвет для статуса
        public string StatusColor
        {
            get
            {
                if (CurrentStock == 0) return "#C62828"; // Красный
                if (CurrentStock <= MinStock) return "#F57C00"; // Оранжевый
                return "#388E3C"; // Зелёный
            }
        }

        // Готовый цвет фона для статуса
        public string StatusBackground
        {
            get
            {
                if (CurrentStock == 0) return "#FFEBEE";
                if (CurrentStock <= MinStock) return "#FFF3E0";
                return "#E8F5E9";
            }
        }
    }

    public partial class StockContent : UserControl
    {
        private List<StockItem> _allItems;
        private List<StockItem> _filteredItems;

        public StockContent()
        {
            InitializeComponent();
            Loaded += StockContent_Loaded;
        }

        public void ForceRefresh()
        {
            LoadData();
        }

        private void StockContent_Loaded(object sender, RoutedEventArgs e) => LoadData();

        private void LoadData()
        {
            try
            {
                if (MainWindow.Warehouse == null) return;

                var products = MainWindow.Warehouse.GetProducts();
                if (products == null) products = new List<Product>();

                // Преобразуем в StockItem с готовыми статусами
                _allItems = products.Select(p => new StockItem { Source = p }).ToList();

                ApplyFilter();
                UpdateInfo();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ApplyFilter()
        {
            var search = TxtSearch?.Text?.ToLower().Trim() ?? "";

            _filteredItems = string.IsNullOrEmpty(search)
                ? _allItems
                : _allItems.Where(p => p.Name.ToLower().Contains(search)).ToList();

            if (DgStock != null)
            {
                DgStock.ItemsSource = _filteredItems;
            }
        }

        private void UpdateInfo()
        {
            var total = _allItems?.Sum(p => p.CurrentStock) ?? 0;
            var count = _filteredItems?.Count ?? 0;
            if (TxtInfo != null)
            {
                TxtInfo.Text = $"Показано: {count} | Всего на складе: {total} ед.";
            }
        }

        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e) => ApplyFilter();

        private void BtnExport_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (MainWindow.Warehouse == null) return;

                var path = $"StockExport_{DateTime.Now:yyyyMMdd_HHmm}.xml";
                var list = _filteredItems?.Select(i => i.Source).ToList() ?? new List<Product>();
                MainWindow.Warehouse.ExportOrdersToXml(list, path);
                MessageBox.Show($"Экспорт выполнен: {path}", "Успех",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка экспорта",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnAddStock_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Tag is int productId)
                ProcessOperation(productId, "In");
        }

        private void BtnRemoveStock_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Tag is int productId)
                ProcessOperation(productId, "Out");
        }

        private void ProcessOperation(int productId, string type)
        {
            var dialog = new OperationDialog(productId, type);
            dialog.Owner = Window.GetWindow(this);
            if (dialog.ShowDialog() == true)
            {
                try
                {
                    MainWindow.Warehouse.TryProcessOperation(productId, dialog.Amount, type);
                    LoadData();
                    MessageBox.Show("Операция выполнена", "Успех",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Ошибка",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
    }
}