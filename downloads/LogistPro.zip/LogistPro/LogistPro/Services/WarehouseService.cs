﻿using LogistPro.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Serialization;

namespace LogistPro.Services
{
    public class WarehouseService
    {
        private readonly IFileService _fileService;
        private List<Product> _products;
        private List<Operation> _operations;

        public WarehouseService(IFileService fileService)
        {
            _fileService = fileService;
            LoadData();
        }

        public void LoadData()
        {
            _products = _fileService.LoadProducts();
            _operations = _fileService.LoadOperations();
            RecalculateStocks();
        }

        // Алгоритм: Пересчет остатков на основе журнала
        private void RecalculateStocks()
        {
            // Сбросим текущие остатки и пересчитаем по операциям для надежности
            var stockDict = _products.ToDictionary(p => p.Id, p => 0);

            foreach (var op in _operations)
            {
                if (stockDict.ContainsKey(op.ProductId))
                {
                    if (op.Type == "In") stockDict[op.ProductId] += op.Amount;
                    else if (op.Type == "Out") stockDict[op.ProductId] -= op.Amount;
                }
            }

            foreach (var p in _products)
            {
                p.CurrentStock = stockDict[p.Id];
            }
        }

        public List<Product> GetProducts() => _products;
        public List<Operation> GetOperations() => _operations;

        // Алгоритм: Проверка и списание
        public bool TryProcessOperation(int productId, int amount, string type)
        {
            var product = _products.FirstOrDefault(p => p.Id == productId);
            if (product == null) return false;

            if (type == "Out" && product.CurrentStock < amount)
            {
                throw new Exception($"Недостаток товара на складе! Остаток: {product.CurrentStock}");
            }

            var newOp = new Operation
            {
                Id = _operations.Count + 1,
                ProductId = productId,
                Amount = amount,
                Type = type,
                Date = DateTime.Now
            };

            _operations.Add(newOp);

            // Обновляем локально
            if (type == "In") product.CurrentStock += amount;
            else product.CurrentStock -= amount;

            SaveData();
            return true;
        }

        // Алгоритм: Выбор товаров с минимальными остатками
        public List<Product> GetLowStockProducts()
        {
            return _products.Where(p => p.CurrentStock <= p.MinStock).ToList();
        }

        // Алгоритм: Расчет рекомендуемого количества
        public int CalculateRecommendedAmount(Product product)
        {
            // Пример логики: довести до 2-х кратного минимума
            int target = product.MinStock * 2;
            int needed = target - product.CurrentStock;
            return needed > 0 ? needed : 0;
        }

        public void SaveData()
        {
            _fileService.SaveProducts(_products);
            _fileService.SaveOperations(_operations);
        }

        public void ExportOrdersToXml(List<Product> orderList, string path)
        {
            var serializer = new XmlSerializer(typeof(List<Product>));
            using (var stream = new FileStream(path, FileMode.Create))
            {
                serializer.Serialize(stream, orderList);
            }
        }
    }
}
