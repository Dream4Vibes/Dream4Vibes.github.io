﻿using System.Collections.Generic;
using LogistPro.Models;

namespace LogistPro.Services
{
    public interface IFileService
    {
        List<Product> LoadProducts();
        void SaveProducts(List<Product> products);
        List<Operation> LoadOperations();
        void SaveOperations(List<Operation> operations);
    }
}