﻿using LogistPro.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Xml.Serialization;

namespace LogistPro.Services
{
    public class FileService : IFileService
    {
        private readonly string _productsPath = "products.xml";
        private readonly string _operationsPath = "journal.xml";

        public List<Product> LoadProducts()
        {
            if (!File.Exists(_productsPath))
                return new List<Product>();

            try
            {
                var serializer = new XmlSerializer(typeof(List<Product>));
                using (var reader = new StreamReader(_productsPath, Encoding.UTF8, true)) // true = detect BOM
                {
                    var result = (List<Product>)serializer.Deserialize(reader);
                    return result ?? new List<Product>();
                }
            }
            catch (Exception ex)
            {
                // Создаём резервную копию битого файла
                File.Copy(_productsPath, _productsPath + ".backup", true);

                // Возвращаем пустой список вместо падения
                return new List<Product>();
            }
        }

        public void SaveProducts(List<Product> products)
        {
            var serializer = new XmlSerializer(typeof(List<Product>));
            using (var stream = new FileStream(_productsPath, FileMode.Create))
            {
                serializer.Serialize(stream, products);
            }
        }

        public List<Operation> LoadOperations()
        {
            if (!File.Exists(_operationsPath)) return new List<Operation>();
            try
            {
                var serializer = new XmlSerializer(typeof(List<Operation>));
                using (var stream = new FileStream(_operationsPath, FileMode.Open))
                {
                    return (List<Operation>)serializer.Deserialize(stream);
                }
            }
            catch (Exception)
            {
                throw new Exception("Ошибка при чтении журнала операций.");
            }
        }

        public void SaveOperations(List<Operation> operations)
        {
            var serializer = new XmlSerializer(typeof(List<Operation>));
            using (var stream = new FileStream(_operationsPath, FileMode.Create))
            {
                serializer.Serialize(stream, operations);
            }
        }
    }
}