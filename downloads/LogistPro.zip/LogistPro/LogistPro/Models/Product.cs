﻿using System.Xml.Serialization;

namespace LogistPro.Models
{
    [XmlRoot("Product")]
    public class Product
    {
        [XmlElement]
        public int Id { get; set; }
        [XmlElement]
        public string Name { get; set; }
        [XmlElement]
        public int CurrentStock { get; set; }
        [XmlElement]
        public int MinStock { get; set; } // Минимальный остаток для заказа
    }
}