﻿using System;
using System.Xml.Serialization;

namespace LogistPro.Models
{
    [XmlRoot("Operation")]
    public class Operation
    {
        [XmlElement]
        public int Id { get; set; }
        [XmlElement]
        public int ProductId { get; set; }
        [XmlElement]
        public string Type { get; set; } // "In" или "Out"
        [XmlElement]
        public int Amount { get; set; }
        [XmlElement]
        public DateTime Date { get; set; }
    }
}