﻿namespace game1
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.bg1 = new System.Windows.Forms.PictureBox();
            this.player = new System.Windows.Forms.PictureBox();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.bg2 = new System.Windows.Forms.PictureBox();
            this.enemy1 = new System.Windows.Forms.PictureBox();
            this.enemy2 = new System.Windows.Forms.PictureBox();
            this.labellose = new System.Windows.Forms.Label();
            this.btnRestart = new System.Windows.Forms.Button();
            this.coin = new System.Windows.Forms.PictureBox();
            this.labelcoins = new System.Windows.Forms.Label();
            this.Продолжить = new System.Windows.Forms.Button();
            this.Выход = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.bg1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.player)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bg2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemy1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemy2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.coin)).BeginInit();
            this.SuspendLayout();
            // 
            // bg1
            // 
            this.bg1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bg1.Image = global::game1.Properties.Resources._1687798031_bogatyr_club_p_doroga_sverkhu_foni_vkontakte_9;
            this.bg1.Location = new System.Drawing.Point(-5, -1);
            this.bg1.Margin = new System.Windows.Forms.Padding(0);
            this.bg1.Name = "bg1";
            this.bg1.Size = new System.Drawing.Size(855, 659);
            this.bg1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bg1.TabIndex = 0;
            this.bg1.TabStop = false;
            this.bg1.UseWaitCursor = true;
            this.bg1.BackgroundImageChanged += new System.EventHandler(this.pictureBox2_BackgroundImageChanged);
            // 
            // player
            // 
            this.player.BackColor = System.Drawing.Color.Transparent;
            this.player.Image = ((System.Drawing.Image)(resources.GetObject("player.Image")));
            this.player.Location = new System.Drawing.Point(451, 479);
            this.player.Name = "player";
            this.player.Size = new System.Drawing.Size(81, 159);
            this.player.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.player.TabIndex = 1;
            this.player.TabStop = false;
            this.player.UseWaitCursor = true;
            this.player.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // timer
            // 
            this.timer.Enabled = true;
            this.timer.Interval = 20;
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // bg2
            // 
            this.bg2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bg2.Image = global::game1.Properties.Resources._1687798031_bogatyr_club_p_doroga_sverkhu_foni_vkontakte_9;
            this.bg2.Location = new System.Drawing.Point(-5, -650);
            this.bg2.Margin = new System.Windows.Forms.Padding(0);
            this.bg2.Name = "bg2";
            this.bg2.Size = new System.Drawing.Size(855, 659);
            this.bg2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bg2.TabIndex = 2;
            this.bg2.TabStop = false;
            this.bg2.UseWaitCursor = true;
            // 
            // enemy1
            // 
            this.enemy1.BackColor = System.Drawing.Color.Transparent;
            this.enemy1.Image = ((System.Drawing.Image)(resources.GetObject("enemy1.Image")));
            this.enemy1.Location = new System.Drawing.Point(192, -200);
            this.enemy1.Name = "enemy1";
            this.enemy1.Size = new System.Drawing.Size(78, 156);
            this.enemy1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.enemy1.TabIndex = 3;
            this.enemy1.TabStop = false;
            this.enemy1.UseWaitCursor = true;
            // 
            // enemy2
            // 
            this.enemy2.BackColor = System.Drawing.Color.Transparent;
            this.enemy2.Image = ((System.Drawing.Image)(resources.GetObject("enemy2.Image")));
            this.enemy2.Location = new System.Drawing.Point(451, -400);
            this.enemy2.Name = "enemy2";
            this.enemy2.Size = new System.Drawing.Size(78, 156);
            this.enemy2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.enemy2.TabIndex = 4;
            this.enemy2.TabStop = false;
            this.enemy2.UseWaitCursor = true;
            // 
            // labellose
            // 
            this.labellose.AutoSize = true;
            this.labellose.BackColor = System.Drawing.Color.Firebrick;
            this.labellose.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labellose.ForeColor = System.Drawing.Color.White;
            this.labellose.Location = new System.Drawing.Point(289, 215);
            this.labellose.Name = "labellose";
            this.labellose.Size = new System.Drawing.Size(274, 42);
            this.labellose.TabIndex = 5;
            this.labellose.Text = "Вы проиграли\r\n";
            this.labellose.UseWaitCursor = true;
            // 
            // btnRestart
            // 
            this.btnRestart.BackColor = System.Drawing.Color.Chartreuse;
            this.btnRestart.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnRestart.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRestart.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnRestart.ForeColor = System.Drawing.Color.White;
            this.btnRestart.Location = new System.Drawing.Point(319, 269);
            this.btnRestart.Name = "btnRestart";
            this.btnRestart.Size = new System.Drawing.Size(213, 39);
            this.btnRestart.TabIndex = 6;
            this.btnRestart.Text = "Перезапустить\r\n\r\n";
            this.btnRestart.UseVisualStyleBackColor = false;
            this.btnRestart.UseWaitCursor = true;
            this.btnRestart.Click += new System.EventHandler(this.btnRestart_Click);
            // 
            // coin
            // 
            this.coin.BackColor = System.Drawing.Color.Transparent;
            this.coin.Image = ((System.Drawing.Image)(resources.GetObject("coin.Image")));
            this.coin.Location = new System.Drawing.Point(460, -600);
            this.coin.Name = "coin";
            this.coin.Size = new System.Drawing.Size(61, 62);
            this.coin.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.coin.TabIndex = 7;
            this.coin.TabStop = false;
            this.coin.UseWaitCursor = true;
            // 
            // labelcoins
            // 
            this.labelcoins.AutoSize = true;
            this.labelcoins.BackColor = System.Drawing.Color.Gold;
            this.labelcoins.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelcoins.ForeColor = System.Drawing.Color.White;
            this.labelcoins.Location = new System.Drawing.Point(12, 9);
            this.labelcoins.Name = "labelcoins";
            this.labelcoins.Size = new System.Drawing.Size(162, 33);
            this.labelcoins.TabIndex = 8;
            this.labelcoins.Text = "Монеты: 0";
            this.labelcoins.UseWaitCursor = true;
            // 
            // Продолжить
            // 
            this.Продолжить.Location = new System.Drawing.Point(319, 215);
            this.Продолжить.Name = "Продолжить";
            this.Продолжить.Size = new System.Drawing.Size(213, 39);
            this.Продолжить.TabIndex = 9;
            this.Продолжить.Text = "Продолжить";
            this.Продолжить.UseVisualStyleBackColor = true;
            this.Продолжить.UseWaitCursor = true;
            this.Продолжить.Click += new System.EventHandler(this.Продолжить_Click);
            // 
            // Выход
            // 
            this.Выход.Location = new System.Drawing.Point(319, 269);
            this.Выход.Name = "Выход";
            this.Выход.Size = new System.Drawing.Size(213, 39);
            this.Выход.TabIndex = 10;
            this.Выход.Text = "Выйти из игры";
            this.Выход.UseVisualStyleBackColor = true;
            this.Выход.UseWaitCursor = true;
            this.Выход.Click += new System.EventHandler(this.Выход_Click);
            // 
            // Form1
            // 
            this.AllowDrop = true;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BackgroundImage = global::game1.Properties.Resources._1687798031_bogatyr_club_p_doroga_sverkhu_foni_vkontakte_9;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.CausesValidation = false;
            this.ClientSize = new System.Drawing.Size(850, 650);
            this.ControlBox = false;
            this.Controls.Add(this.Выход);
            this.Controls.Add(this.Продолжить);
            this.Controls.Add(this.labelcoins);
            this.Controls.Add(this.coin);
            this.Controls.Add(this.btnRestart);
            this.Controls.Add(this.labellose);
            this.Controls.Add(this.enemy2);
            this.Controls.Add(this.enemy1);
            this.Controls.Add(this.player);
            this.Controls.Add(this.bg1);
            this.Controls.Add(this.bg2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.UseWaitCursor = true;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            ((System.ComponentModel.ISupportInitialize)(this.bg1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.player)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bg2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemy1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemy2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.coin)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox bg1;
        private System.Windows.Forms.PictureBox player;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.PictureBox bg2;
        private System.Windows.Forms.PictureBox enemy1;
        private System.Windows.Forms.PictureBox enemy2;
        private System.Windows.Forms.Label labellose;
        private System.Windows.Forms.Button btnRestart;
        private System.Windows.Forms.PictureBox coin;
        private System.Windows.Forms.Label labelcoins;
        private System.Windows.Forms.Button Продолжить;
        private System.Windows.Forms.Button Выход;
    }
}

