﻿namespace game1
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.bg1 = new System.Windows.Forms.PictureBox();
            this.player = new System.Windows.Forms.PictureBox();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.bg2 = new System.Windows.Forms.PictureBox();
            this.enemy1 = new System.Windows.Forms.PictureBox();
            this.enemy2 = new System.Windows.Forms.PictureBox();
            this.labellose = new System.Windows.Forms.Label();
            this.btnRestart = new System.Windows.Forms.Button();
            this.coin = new System.Windows.Forms.PictureBox();
            this.labelcoins = new System.Windows.Forms.Label();
            this.Продолжить = new System.Windows.Forms.Button();
            this.Выход = new System.Windows.Forms.Button();
            this.Ohki = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.Records = new System.Windows.Forms.Button();
            this.lablerecords = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.bg1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.player)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bg2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemy1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemy2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.coin)).BeginInit();
            this.SuspendLayout();
            // 
            // bg1
            // 
            this.bg1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bg1.Image = global::game1.Properties.Resources._1687798031_bogatyr_club_p_doroga_sverkhu_foni_vkontakte_9;
            this.bg1.Location = new System.Drawing.Point(-3, 0);
            this.bg1.Margin = new System.Windows.Forms.Padding(0);
            this.bg1.Name = "bg1";
            this.bg1.Size = new System.Drawing.Size(855, 659);
            this.bg1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bg1.TabIndex = 0;
            this.bg1.TabStop = false;
            // 
            // player
            // 
            this.player.BackColor = System.Drawing.Color.Transparent;
            this.player.Image = ((System.Drawing.Image)(resources.GetObject("player.Image")));
            this.player.Location = new System.Drawing.Point(451, 479);
            this.player.Name = "player";
            this.player.Size = new System.Drawing.Size(81, 159);
            this.player.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.player.TabIndex = 1;
            this.player.TabStop = false;
            // 
            // timer
            // 
            this.timer.Enabled = true;
            this.timer.Interval = 20;
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // bg2
            // 
            this.bg2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bg2.Image = global::game1.Properties.Resources._1687798031_bogatyr_club_p_doroga_sverkhu_foni_vkontakte_9;
            this.bg2.Location = new System.Drawing.Point(-3, -650);
            this.bg2.Margin = new System.Windows.Forms.Padding(0);
            this.bg2.Name = "bg2";
            this.bg2.Size = new System.Drawing.Size(855, 659);
            this.bg2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bg2.TabIndex = 2;
            this.bg2.TabStop = false;
            // 
            // enemy1
            // 
            this.enemy1.BackColor = System.Drawing.Color.Transparent;
            this.enemy1.Image = ((System.Drawing.Image)(resources.GetObject("enemy1.Image")));
            this.enemy1.Location = new System.Drawing.Point(192, -200);
            this.enemy1.Name = "enemy1";
            this.enemy1.Size = new System.Drawing.Size(78, 156);
            this.enemy1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.enemy1.TabIndex = 3;
            this.enemy1.TabStop = false;
            // 
            // enemy2
            // 
            this.enemy2.BackColor = System.Drawing.Color.Transparent;
            this.enemy2.Image = ((System.Drawing.Image)(resources.GetObject("enemy2.Image")));
            this.enemy2.Location = new System.Drawing.Point(451, -400);
            this.enemy2.Name = "enemy2";
            this.enemy2.Size = new System.Drawing.Size(78, 156);
            this.enemy2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.enemy2.TabIndex = 4;
            this.enemy2.TabStop = false;
            // 
            // labellose
            // 
            this.labellose.AutoSize = true;
            this.labellose.BackColor = System.Drawing.Color.Firebrick;
            this.labellose.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labellose.ForeColor = System.Drawing.Color.White;
            this.labellose.Location = new System.Drawing.Point(289, 215);
            this.labellose.Name = "labellose";
            this.labellose.Size = new System.Drawing.Size(274, 42);
            this.labellose.TabIndex = 5;
            this.labellose.Text = "Вы проиграли\r\n";
            // 
            // btnRestart
            // 
            this.btnRestart.BackColor = System.Drawing.Color.Chartreuse;
            this.btnRestart.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnRestart.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRestart.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnRestart.ForeColor = System.Drawing.Color.White;
            this.btnRestart.Location = new System.Drawing.Point(319, 269);
            this.btnRestart.Name = "btnRestart";
            this.btnRestart.Size = new System.Drawing.Size(213, 39);
            this.btnRestart.TabIndex = 6;
            this.btnRestart.Text = "Перезапустить\r\n\r\n";
            this.btnRestart.UseVisualStyleBackColor = false;
            this.btnRestart.Click += new System.EventHandler(this.btnRestart_Click);
            // 
            // coin
            // 
            this.coin.BackColor = System.Drawing.Color.Transparent;
            this.coin.Image = ((System.Drawing.Image)(resources.GetObject("coin.Image")));
            this.coin.Location = new System.Drawing.Point(460, -600);
            this.coin.Name = "coin";
            this.coin.Size = new System.Drawing.Size(61, 62);
            this.coin.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.coin.TabIndex = 7;
            this.coin.TabStop = false;
            // 
            // labelcoins
            // 
            this.labelcoins.AutoSize = true;
            this.labelcoins.BackColor = System.Drawing.Color.Gold;
            this.labelcoins.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelcoins.ForeColor = System.Drawing.Color.White;
            this.labelcoins.Location = new System.Drawing.Point(12, 9);
            this.labelcoins.Name = "labelcoins";
            this.labelcoins.Size = new System.Drawing.Size(162, 33);
            this.labelcoins.TabIndex = 8;
            this.labelcoins.Text = "Монеты: 0";
            // 
            // Продолжить
            // 
            this.Продолжить.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Продолжить.Location = new System.Drawing.Point(319, 314);
            this.Продолжить.Name = "Продолжить";
            this.Продолжить.Size = new System.Drawing.Size(213, 39);
            this.Продолжить.TabIndex = 9;
            this.Продолжить.Text = "Продолжить";
            this.Продолжить.UseVisualStyleBackColor = true;
            this.Продолжить.Click += new System.EventHandler(this.Продолжить_Click);
            // 
            // Выход
            // 
            this.Выход.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Выход.Location = new System.Drawing.Point(319, 359);
            this.Выход.Name = "Выход";
            this.Выход.Size = new System.Drawing.Size(213, 39);
            this.Выход.TabIndex = 10;
            this.Выход.Text = "Выйти из игры";
            this.Выход.UseVisualStyleBackColor = true;
            this.Выход.Click += new System.EventHandler(this.Выход_Click);
            // 
            // Ohki
            // 
            this.Ohki.BackColor = System.Drawing.Color.IndianRed;
            this.Ohki.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Ohki.ForeColor = System.Drawing.Color.White;
            this.Ohki.Location = new System.Drawing.Point(668, 9);
            this.Ohki.Name = "Ohki";
            this.Ohki.Size = new System.Drawing.Size(170, 33);
            this.Ohki.TabIndex = 11;
            this.Ohki.Text = "Очки: 0";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Records
            // 
            this.Records.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Records.Location = new System.Drawing.Point(12, 593);
            this.Records.Name = "Records";
            this.Records.Size = new System.Drawing.Size(303, 45);
            this.Records.TabIndex = 12;
            this.Records.Text = "Показать рекорды";
            this.Records.UseVisualStyleBackColor = true;
            this.Records.Visible = false;
            this.Records.Click += new System.EventHandler(this.Records_Click);
            // 
            // lablerecords
            // 
            this.lablerecords.AutoSize = true;
            this.lablerecords.BackColor = System.Drawing.Color.Yellow;
            this.lablerecords.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lablerecords.Location = new System.Drawing.Point(290, 401);
            this.lablerecords.Name = "lablerecords";
            this.lablerecords.Size = new System.Drawing.Size(327, 33);
            this.lablerecords.TabIndex = 13;
            this.lablerecords.Text = "Место ваших рекордов";
            this.lablerecords.Visible = false;
            // 
            // Form1
            // 
            this.AllowDrop = true;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BackgroundImage = global::game1.Properties.Resources._1687798031_bogatyr_club_p_doroga_sverkhu_foni_vkontakte_9;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.CausesValidation = false;
            this.ClientSize = new System.Drawing.Size(850, 650);
            this.ControlBox = false;
            this.Controls.Add(this.lablerecords);
            this.Controls.Add(this.Records);
            this.Controls.Add(this.Ohki);
            this.Controls.Add(this.Выход);
            this.Controls.Add(this.Продолжить);
            this.Controls.Add(this.labelcoins);
            this.Controls.Add(this.coin);
            this.Controls.Add(this.btnRestart);
            this.Controls.Add(this.labellose);
            this.Controls.Add(this.enemy2);
            this.Controls.Add(this.enemy1);
            this.Controls.Add(this.player);
            this.Controls.Add(this.bg1);
            this.Controls.Add(this.bg2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            ((System.ComponentModel.ISupportInitialize)(this.bg1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.player)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bg2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemy1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemy2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.coin)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox bg1;
        private System.Windows.Forms.PictureBox player;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.PictureBox bg2;
        private System.Windows.Forms.PictureBox enemy1;
        private System.Windows.Forms.PictureBox enemy2;
        private System.Windows.Forms.Label labellose;
        private System.Windows.Forms.Button btnRestart;
        private System.Windows.Forms.PictureBox coin;
        private System.Windows.Forms.Label labelcoins;
        private System.Windows.Forms.Button Продолжить;
        private System.Windows.Forms.Button Выход;
        private System.Windows.Forms.Label Ohki;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button Records;
        private System.Windows.Forms.Label lablerecords;
    }
}

