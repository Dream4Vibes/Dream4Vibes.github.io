﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace game1
{
    public partial class Form1 : Form
    {

        private Point pos;
        private bool dragging, lose = false;
        private int countCoins = 0;
        private int countohki = 0;
        private int recordOhki = 0;
        private int recordCoins = 0;

        public Form1()
        {
            InitializeComponent();

            bg1.MouseDown += MouseClickDown;
            bg1.MouseUp += MouseClickUp;
            bg1.MouseMove += MouseClickMove;
            bg2.MouseDown += MouseClickDown;
            bg2.MouseUp += MouseClickUp;
            bg2.MouseMove += MouseClickMove;

            labellose.Visible = false;
            btnRestart.Visible = false;
            KeyPreview = true;
        }

        private void MouseClickDown(object sender, MouseEventArgs e)
        {
            dragging = true;
            pos.X = e.X;
            pos.Y = e.Y;
        }

        private void MouseClickUp(object sender, MouseEventArgs e)
        {
            dragging = false;
        }

        private void MouseClickMove(object sender, MouseEventArgs e)
        {
            if (dragging)
            {
                Point currPoint = PointToScreen(new Point(e.X, e.Y));
                this.Location = new Point(currPoint.X - pos.X, currPoint.Y - pos.Y + bg1.Top);
            }
        }

        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Escape)
            {
                timer.Stop();
                timer1.Stop();
                Продолжить.Visible = true;
                Выход.Visible = true;
                Records.Visible = true;
            }
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            Продолжить.Visible = false;
            Выход.Visible = false;

            int speed = 5;
            bg1.Top += speed;
            bg2.Top += speed;

            int carSpeed = 7;
            enemy1.Top += carSpeed;
            enemy2.Top += carSpeed;

            coin.Top += speed;

            if (bg1.Top >= 650)

            {
                bg1.Top = 0;
                bg2.Top = -650;
            }

            if (coin.Top >= 650)
            {

                coin.Top = -180;
                Random rand = new Random();
                coin.Left = rand.Next(150, 660);
            }

            if (enemy1.Top >= 650)
            {
                enemy1.Top = -200;
                Random rand = new Random();
                enemy1.Left = rand.Next(150, 300);
            }

            if (enemy2.Top >= 650)
            {
                enemy2.Top = -400;
                Random rand = new Random();
                enemy2.Left = rand.Next(300, 560);
            }

            if (player.Bounds.IntersectsWith(enemy1.Bounds)
                || player.Bounds.IntersectsWith(enemy2.Bounds))
            {
                timer.Enabled = false;
                timer1.Enabled = false;
                labellose.Visible = true;
                btnRestart.Visible = true;
                lose = true;
                Выход.Visible = true;
                Records.Visible = true;
            }

            if (player.Bounds.IntersectsWith(coin.Bounds))
            {
                countCoins++;
                labelcoins.Text = "Монеты: " + countCoins.ToString();
                coin.Top = -180;
                Random rand = new Random();
                coin.Left = rand.Next(150, 660);
            }
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (lose) return;

            int speed = 10;
            if (e.KeyCode == Keys.Left && player.Left > 150)
                player.Left -= speed;
            else if (e.KeyCode == Keys.Right && player.Right < 700)
                player.Left += speed;
            if (e.KeyCode == Keys.Up && player.Top > 50)
                player.Top -= speed;
            else if (e.KeyCode == Keys.Down && player.Bottom < 600)
                player.Top += speed;
        }

        private void Продолжить_Click(object sender, EventArgs e)
        {
            timer.Start();
            timer1.Start();
            Продолжить.Visible = false;
            Выход.Visible = false;
            Records.Visible = false;
            lablerecords.Visible = false;
        }

        private void Выход_Click(object sender, EventArgs e)
        {
            this.Close();
            SaveGameData();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            countohki++;
            Ohki.Text = "Очки: " + countohki.ToString();
        }

        private void btnRestart_Click(object sender, EventArgs e)
        {
            enemy1.Top = -200;
            enemy2.Top = -400;
            labellose.Visible = false;
            btnRestart.Visible = false;
            lablerecords.Visible = false;
            timer.Enabled = true;
            timer1.Enabled = true;
            lose = false;
            Records.Visible = false;
            countCoins = 0;
            labelcoins.Text = "Монеты: 0";
            Ohki.Text = "Очки: 0";
            coin.Top = -600;
            player.Location = new Point(451, 479);
        }

        private void SaveGameData()
        {
            try
            {
                // Локальный путь для сохранений (в AppData/Roaming)
                string localAppData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
                string gameFolder = Path.Combine(localAppData, "game1");
                string filePath = Path.Combine(gameFolder, "Число монет и счёт.txt");

                // Создаём папку, если её нет
                Directory.CreateDirectory(gameFolder);

                bool isNewRecord = false;

                if (countohki > recordOhki)
                {
                    recordOhki = countohki;
                    isNewRecord = true;
                }

                if (countCoins > recordCoins)
                {
                    recordCoins = countCoins;
                    isNewRecord = true;
                }

                if (isNewRecord)
                {
                    string dataToSave = $"Очки: {recordOhki}, Монеты: {recordCoins}";
                    File.WriteAllText(filePath, dataToSave);
                    MessageBox.Show("Новый рекорд!", "Ура!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadGameRecords();
        }

        private void Records_Click(object sender, EventArgs e)
        {
            lablerecords.Text = $"════ РЕКОРДЫ ════\n" +
                   $"█ Очки: {recordOhki}\n" +
                   $"█ Монеты: {recordCoins}\n" +
                   $"══════════════════════";

            lablerecords.Visible = true;


        }

        private void LoadGameRecords()
        {
            try
            {
                string localAppData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
                string gameFolder = Path.Combine(localAppData, "game1");
                string filePath = Path.Combine(gameFolder, "Число монет и счёт.txt");

                if (File.Exists(filePath))
                {
                    string[] lines = File.ReadAllLines(filePath);
                    foreach (string line in lines)
                    {
                        if (line.Contains("Очки:") && line.Contains("Монеты:"))
                        {
                            string[] parts = line.Split(new[] { ", " }, StringSplitOptions.None);

                            if (parts.Length >= 2)
                            {
                                if (int.TryParse(parts[0].Replace("Очки: ", ""), out int ohki))
                                    recordOhki = ohki;

                                if (int.TryParse(parts[1].Replace("Монеты: ", ""), out int coins))
                                    recordCoins = coins;
                            }
                        }
                    }
                }
                else
                {
                    // Файл не существует — можно инициализировать нулями или игнорировать
                    recordOhki = 0;
                    recordCoins = 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Не удалось загрузить рекорды: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                // При ошибке можно сбросить рекорды или оставить как есть
            }
        }
    }
}
